<!doctype html>
<html lang="de">
   <head>
   <title>Schwarzes Brett</title>
   <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
   <link rel="stylesheet" type="text/css" href="base.css" media="screen" />
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
   </head>

<body>
 
<!-- Schwarzes Brett Navbar -->
<div class="headertop"></div>
<div class="navigation">
 <ul>
  <li><a href="index.php"><i class="fas fa-home"></i></a></li>
  <li><a href="eingabe.php"><i class="fas fa-align-left"></i></a></li>
  <li ><a href="kategorien.php"><i class="fas fa-list"></i></a> 
                 <ul>
               <a href="ausgabe.php?portal=1" class="navigationlinks"><li>Informationen</li></a>
               <a href="ausgabe.php?portal=2" class="navigationlinks"><li>Kantinenplan</li></a>
               <a href="ausgabe.php?portal=3" class="navigationlinks"><li>Freizeitangebote</li></a>
               <a href="ausgabe.php?portal=4" class="navigationlinks"><li>Naechste Termine</li></a>
               <a href="ausgabe.php?portal=5" class="navigationlinks"><li>Stellenanzeigen</li></a>
               </ul>
  </li>
  <li> <?php
$servername = "localhost";
$username = "root";
$password = "";
error_reporting(0);
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die(" <div title=\"Server: Offline - Bitte wenden Sie sich an Herr Stenke\" class=\"servercheckbad\"><i class=\"fas fa-network-wired\"></i></div>");
}
echo "<div title=\"Server: Online\" class=\"servercheckgood\"><i class=\"fas fa-network-wired\"></i></div>"
?> </li>
</ul> 
</div>
<div class="headerbottom"></div>


<?php
// Kategorien auslesen
$query="SELECT rubriknummer, rubrikbezeichnung FROM rubrik ORDER BY rubrikbezeichnung";
$ergebnis=mysqli_query($query,$conn);
if(!$ergebnis)
	echo mysqli_error();
?> 


<!-- Inhalt -->
<div class="inhalt">
<h1> Schwarzes Brett</h1>
<p><strong>Impressum</strong></p>
<p>Anbieter:<br/>Gerd Wei<br/>Tessenowweg 3<br />22297 Hamburg</p></br>
<p><strong>Kontakt:</strong><br/>Telefon: 040/ 7788341<br/>Telefax: 040/ 7788347<br/>E-Mail: schwarzesbrett@bs28-citynord.hamburg<br/>Website: www.bs28-citynord.de</p>
<p> </p>
<p><strong>Bei redaktionellen Inhalten:</strong></p>
<p>Verantwortlich nach § 55 Abs.2 RStV<br />Moritz Schreiber<br/>Washingtonallee 2<br/>22111 Hamburg</p>
</div>


<!-- Footer mit Impressum -->
<div class="footer">
<a href="impressum.php">Impressum</a>
			</div>
			</div>
   </body>
</html>