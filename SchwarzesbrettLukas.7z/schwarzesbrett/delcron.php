
					<!-- Delcron der -14 Tage Anzeigen -->	
					<?php
					
						$servername = "localhost";
						$user = "root"; 
						$pw = ""; 			
						$db = "schwarzesbrett"; 		

						$timestamp = time();

						$datum = date("Y-m-d", $timestamp);
								
						$datum_delete = strtotime("-14 day");
						
						$datum_delete_anzeige = date("Y-m-d", $datum_delete);
					
					$con = new mysqli($servername, $user, $pw, $db);
					
					if($con->connect_error) {
						
						die("Loeschung aelterer Betraege nicht moeglich!".$con->connect_error);
					}
					
					$con->set_charset("utf8mb4");
					
						$sql = "DELETE FROM anzeige WHERE anzeigendatum < '" . $datum_delete_anzeige . "'";
		
					if ($con->query($sql) === TRUE) {
					} else {
						echo "Error: " . $sql . "<br>" . $conn->error;
					}

					
					$con->close();

						
					?>
