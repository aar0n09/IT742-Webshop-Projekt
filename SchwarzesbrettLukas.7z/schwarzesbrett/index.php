<!doctype html>
<html lang="de">
   <head>
   <title>Schwarzes Brett</title>
   <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
   <link rel="stylesheet" type="text/css" href="base.css" media="screen" />
   <link  rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
   </head>

<body>
<!-- Ausfuehren des Loeschcrons -->
 <?php
 include 'delcron.php';
 ?>
<!-- Schwarzes Brett Navbar -->
<div class="headertop"></div>
<div class="navigation">
 <ul>
  <li><a href="index.php"><i class="fas fa-home"></i></a></li>
  <li><a href="eingabe.php"><i class="fas fa-align-left"></i></a></li>
  <li ><a href="kategorien.php"><i class="fas fa-list"></i></a> 
                 <ul>
               <a href="ausgabe.php?portal=1" class="navigationlinks"><li>Informationen</li></a>
               <a href="ausgabe.php?portal=2" class="navigationlinks"><li>Kantinenplan</li></a>
               <a href="ausgabe.php?portal=3" class="navigationlinks"><li>Freizeitangebote</li></a>
               <a href="ausgabe.php?portal=4" class="navigationlinks"><li>Naechste Termine</li></a>
               <a href="ausgabe.php?portal=5" class="navigationlinks"><li>Stellenanzeigen</li></a>
               </ul>
  </li>
  <li> <?php
$servername = "localhost";
$username = "root";
$password = "";
error_reporting(0);
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die(" <div title=\"Server: Offline - Bitte wenden Sie sich an Herr Stenke\" class=\"servercheckbad\"><i class=\"fas fa-network-wired\"></i></div>");
}
echo "<div title=\"Server: Online\" class=\"servercheckgood\"><i class=\"fas fa-network-wired\"></i></div>"
?> </li>
</ul> 
</div>
<div class="headerbottom"></div>


<div class="head">
<!-- Inhalt -->
<div class="inhalt">
<h1> Schwarzes Brett</h1>
<h2> Herzlich Willkommen auf dem "Schwarzen Brett"!</h2>
<h2> Hier finden Sie u.a. diverse Informationen zum Unternehmen, Stellenangebote oder auch den wöchentlichen Kantinenplan...</h2>
<h2> Wichtiges:</h2>
<b>- Notfalltelefonnummern:</b></br>
110 / 112</br>
</br>
<b>- Ansprechpartner für spezielle Fragen:</b></br>
Name: Herr Stenke</br>
E-Mail Adresse: stenke@bs28-citynord.hamburg</br>
</br>
<b>- Öffnungszeiten:</b></br>
Montag bis Donnerstag: 08:00 Uhr - 17:00 Uhr</br>
Freitags: 08:00 Uhr - 13:00 Uhr</br>
</br>
<b>- Telefonisch erreichbar:</b></br>
Telefonnummer: 040/ 7782944</br>
Montag bis Freitag 08:00 Uhr - 17:00 Uhr</br>
</br>
</div>

<div class="inhalt">
<hr>
Die unterschiedlichen Themen werden unter folgendem Button noch einmal aufgelistet:</br>
<div class="button"><a href="kategorien.php"><i class="fas fa-arrow-right"></i> Zu den Kategorien</a></div>

Sie wissen bereits welche Kategorie Sie nutzen moechten? Hier geht es direkt zum Eingabeformular:
<div class="button"><a href="eingabe.php"><i class="fas fa-arrow-right"></i> Zum Formular</a></div>
<hr>

<h2>Aktuelles:</h2>
</div>
<!-- Datenbank Abfrage-->
<div class="listegesamt">
<?php

					$servername = "localhost";
					$user = "root"; 				
					$pw = ""; 		
					$db = "schwarzesbrett"; 
					
					$timestamp = time();					
					$datum = date("Y-m-d", $timestamp);

					$portal = ($_GET['portal']);
					
					$con = new mysqli($servername, $user, $pw, $db);							
					if($con->connect_error) {
						
						die("Verbindung zum Server fehlgeschlagen!".$con->connect_error);
					}
					$sql = "SELECT anzeigendatum,nickname,anzeigetext,email,rubriknummer,anzeigennummer FROM anzeige, inserent WHERE anzeige.inserentennummer=inserent.inserentennummer GROUP BY anzeigennummer"; 
$db_gesamt = mysqli_query( $con, $sql );
if ( ! $db_gesamt )
{
  die('Fehler bei der Anfrage! Bitte wenden Sie sich an den Systemadministrator P. Stenke ' . mysqli_error());
}
 
 
while($ausgabe = mysqli_fetch_object($db_gesamt))
{
  echo "<span class=\"tabellenicongross\"> <i class=\"fas fa-male\"></i></span><span class=\"tabellentextgross\"> $ausgabe->nickname</span>";
  echo "<br />";
  echo "<span class=\"tabellenicon\"><i class=\"fas fa-envelope\"></i></span> $ausgabe->email";
  echo "<br />"; 
  echo "<span class=\"tabellenicon\"><i class=\"fas fa-table\"></i></span> $ausgabe->anzeigendatum";
  echo "<br />"; 
  echo "<span class=\"tabellenicon\"><i class=\"fas fa-align-left\"></i></span> $ausgabe->anzeigetext";
  echo "<br /><hr><br />";
}
mysqli_free_result( $db_gesamt );
?>
</div>
<!-- Footer mit Impressum -->
<div class="footer">
<a href="impressum.php">Impressum</a>
			</div>
			</div>
   </body>
</html>