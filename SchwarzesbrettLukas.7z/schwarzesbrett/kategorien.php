<!doctype html>
<html lang="de">
   <head>
   <title>Schwarzes Brett</title>
   <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
   <link rel="icon" href="/favicon.ico" type="image/x-icon">
   <link rel="stylesheet" type="text/css" href="base.css" media="screen" />
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
   </head>

<body>
 
<!-- Schwarzes Brett Navbar -->
<div class="headertop"></div>
<div class="navigation">
 <ul>
  <li><a href="index.php"><i class="fas fa-home"></i></a></li>
  <li><a href="eingabe.php"><i class="fas fa-align-left"></i></a></li>
  <li ><a href="kategorien.php"><i class="fas fa-list"></i></a> 
                 <ul>
               <a href="ausgabe.php?portal=1" class="navigationlinks"><li>Informationen</li></a>
               <a href="ausgabe.php?portal=2" class="navigationlinks"><li>Kantinenplan</li></a>
               <a href="ausgabe.php?portal=3" class="navigationlinks"><li>Freizeitangebote</li></a>
               <a href="ausgabe.php?portal=4" class="navigationlinks"><li>Naechste Termine</li></a>
               <a href="ausgabe.php?portal=5" class="navigationlinks"><li>Stellenanzeigen</li></a>
               </ul>
  </li>
  <li> <?php
$servername = "localhost";
$username = "root";
$password = "";
error_reporting(0);
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die(" <div title=\"Server: Offline - Bitte wenden Sie sich an Herr Stenke\" class=\"servercheckbad\"><i class=\"fas fa-network-wired\"></i></div>");
}
echo "<div title=\"Server: Online\" class=\"servercheckgood\"><i class=\"fas fa-network-wired\"></i></div>"
?> </li>
</ul> 
</div>
<div class="headerbottom"></div>

<div class="head">

<!-- Gallery -->
<div class="gallery">
  <a href="ausgabe.php?portal=1" target="_self" href="information.jpg">
    <img src="information.jpg" alt="Informationen" width="250" height="250">
  </a>
  <div class="desc">Informationen</div>
</div>

<div class="gallery">
  <a target="_self" href="ausgabe.php?portal=2">
    <img src="kantine.jpg" alt="Kantinenplan" width="250" height="250">
  </a>
  <div class="desc">Kantinenplan</div>
</div>

<div class="gallery">
  <a target="_self" href="ausgabe.php?portal=3">
    <img src="freizeit.jpg" alt="Freizeitangebote" width="250" height="250">
  </a>
  <div class="desc">Freizeitangebote</div>
</div>

<div class="gallery">
  <a target="_self" href="ausgabe.php?portal=4">
    <img src="termin.jpg" alt="Nächste Termine" width="250" height="250">
  </a>
  <div class="desc">Nächste Termine</div>
</div>

<div class="gallery">
  <a target="_self" href="ausgabe.php?portal=5">
    <img src="stellen.jpg" alt="Stellenanzeigen" width="250" height="250">
  </a>
  <div class="desc">Stellenanzeigen</div>
</div>

<div class="gallery">
  <a href="eingabe.php" target="_self" href="eingabe.jpg">
    <img src="eingabe.jpg" alt="Zur Eingabe" width="250" height="250">
  </a>
  <div class="desc">Zur Eingabe</div>
</div>

<!-- Footer mit Impressum -->
<div class="footer">
<a href="impressum.php">Impressum</a>
</div>
		</div>
		
   </body>
</html>