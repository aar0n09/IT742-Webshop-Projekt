<!doctype html>
<html lang="de">
   <head>
   <title>Schwarzes Brett</title>
   <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
   
   <link rel="stylesheet" type="text/css" href="base.css" media="screen" />
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
   </head>

<body>
 
<!-- Schwarzes Brett Navbar -->
<div class="headertop"></div>
<div class="head"> 
 <ul>
  <li><a href="index.php"><i class="fas fa-home"></i></a></li>
  <li><a href="eingabe.php"><i class="fas fa-align-left"></i></a></li>
  <li><a href="kategorien.php"><i class="fas fa-list"></i></a></li>
  <li> <?php
$servername = "localhost";
$username = "root";
$password = "";
error_reporting(0);
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die(" <div class=\"servercheckbad\"><i class=\"fas fa-network-wired\"></i></div>");
}
echo "<div class=\"servercheckgood\"><i class=\"fas fa-network-wired\"></i></div>"
?> </li>
</ul> 
<div class="headerbottom"></div>

<!-- Datenbank Abfrage-->
<div class="liste">
<?php

					$servername = "localhost";
					$user = "root"; 				
					$pw = ""; 		
					$db = "schwarzesbrett"; 
					
					$timestamp = time();					
					$datum = date("Y-m-d", $timestamp);

					$portal = ($_GET['portal']);
					
					$con = new mysqli($servername, $user, $pw, $db);							
					if($con->connect_error) {
						
						die("Verbindung zum Server fehlgeschlagen!".$con->connect_error);
					}
					$sql = "SELECT anzeigendatum,nickname,anzeigetext,email,rubriknummer,anzeigennummer FROM anzeige, inserent WHERE anzeige.inserentennummer=inserent.inserentennummer AND anzeige.rubriknummer=$portal GROUP BY anzeigennummer"; 
$db_gesamt = mysqli_query( $con, $sql );
if ( ! $db_gesamt )
{
  die('Fehler bei der Anfrage! Bitte wenden Sie sich an den Systemadministrator P. Stenke ' . mysqli_error());
}
 
 
while($ausgabe = mysqli_fetch_object($db_gesamt))
{
  echo "<span class=\"tabellenicongross\"> <i class=\"fas fa-male\"></i></span><span class=\"tabellentextgross\"> $ausgabe->nickname</span>";
  echo "<br />";
  echo "<span class=\"tabellenicon\"><i class=\"fas fa-envelope\"></i></span> $ausgabe->email";
  echo "<br />"; 
  echo "<span class=\"tabellenicon\"><i class=\"fas fa-table\"></i></span> $ausgabe->anzeigendatum";
  echo "<br />"; 
  echo "<span class=\"tabellenicon\"><i class=\"fas fa-align-left\"></i></span> $ausgabe->anzeigetext";
  echo "<br /><hr><br />";
}
mysqli_free_result( $db_gesamt );
?>
</div>
<!-- Footer mit Impressum -->
<div class="footerausgabe">
<a href="impressum.php">Impressum</a>
			</div>
			</div>
   </body>
</html>