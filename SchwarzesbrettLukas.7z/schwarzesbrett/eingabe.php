<!doctype html>
<html lang="de">
   <head>
   <title>Schwarzes Brett</title>
   <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
   <link rel="icon" href="favicon.ico" type="image/x-icon">
   <link rel="stylesheet" type="text/css" href="base.css" media="screen" />
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
   </head>

<body>
 
<!-- Schwarzes Brett Navbar -->
<div class="headertop"></div>
<div class="navigation">
 <ul>
  <li><a href="index.php"><i class="fas fa-home"></i></a></li>
  <li><a href="eingabe.php"><i class="fas fa-align-left"></i></a></li>
  <li ><a href="kategorien.php"><i class="fas fa-list"></i></a> 
                 <ul>
               <a href="ausgabe.php?portal=1" class="navigationlinks"><li>Informationen</li></a>
               <a href="ausgabe.php?portal=2" class="navigationlinks"><li>Kantinenplan</li></a>
               <a href="ausgabe.php?portal=3" class="navigationlinks"><li>Freizeitangebote</li></a>
               <a href="ausgabe.php?portal=4" class="navigationlinks"><li>Naechste Termine</li></a>
               <a href="ausgabe.php?portal=5" class="navigationlinks"><li>Stellenanzeigen</li></a>
               </ul>
  </li>
  <li> <?php
$servername = "localhost";
$username = "root";
$password = "";
error_reporting(0);
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die(" <div title=\"Server: Offline - Bitte wenden Sie sich an Herr Stenke\" class=\"servercheckbad\"><i class=\"fas fa-network-wired\"></i></div>");
}
echo "<div title=\"Server: Online\" class=\"servercheckgood\"><i class=\"fas fa-network-wired\"></i></div>"
?> </li>
</ul> 
</div>
<div class="headerbottom"></div>


<div class="head">

<!-- Inhalt -->
<div class="inhalt">
<h1> Schwarzes Brett</h1>
<h2> Eingabe</h2>
					<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
					
						<div class="formularabstand">
							<label for="1">Benutzer ID:</label>
							<input class="formular" type="text" id="1" name="name" placeholder="Name"></br>
						</div>
						<div class="formularabstand">							
							<label for="2">Mail:</label>
							<input class="formular" type="text" id="2" name="mail" placeholder="Mailadresse"></br>
						</div>
						<div class="formularabstand">
							<label for="3">Kategorie:</label>
							<select id="3" name="kategorie">
								<option value="1">Allgemeine Informationen</option>
								<option value="2">Kantinenplan</option>
								<option value="3">Freizeitangebote</option>
								<option value="4">Termine</option>
								<option value="5">Stellenanzeigen</option>

							
							</select></br>
						</div>
						<div class="formularabstand">							
							<label for="4">Text:</label>
							<textarea class="formular" id="4" name="text" placeholder="Inhalt der Anzeige"></textarea></br>
</div>
<div class="senden">			
							<a class="senden" href="#"><input class="senden" type="submit" name="senden" value="Absenden"></a>
							<br><br><br><br>
</div>						
						
					</form>				
</div>
<!-- Formular -> Datenbank -->
<?php
					$servername = "localhost";
					$user = "root"; 				
					$pw = ""; 		
					$db = "schwarzesbrett"; 											
					$timestamp = time();					
					$datum = date("Y-m-d", $timestamp);
				if(isset($_POST['senden'])) 
				{			
					$con = new mysqli($servername, $user, $pw, $db);							
					if($con->connect_error) {
						
						die("Verbindung zum Server fehlgeschlagen!".$con->connect_error);
					}
					$con->set_charset("utf8mb4");						
						$name = $_POST['name'];
						$mail = $_POST['mail'];
						$kategorie = $_POST['kategorie'];
						$text = $_POST['text'];
						$datum = $datum;

					$sql = "INSERT INTO `anzeige` (`anzeigennummer`, `inserentennummer`, `anzeigetext`, `anzeigendatum`, `rubriknummer`) 
						VALUES 
						(NULL, '" . $name . "', '" . $text . "', '" . $datum . "', '" . $kategorie . "')";
				
					if ($con->query($sql) === TRUE) {
						echo "Deine Anfrage wurde akzeptiert!";
					} else {
						echo "Error: " . $sql . "<br>" . $conn->error;
					}														
					$con->close();
				}
?>

<!-- Footer mit Impressum -->
<div class="footer">
<a href="impressum.php">Impressum</a>
			</div>
			</div>
   </body>
</html>